package basic03.oper;

public class OpTest01 {
	public static void main(String[] args) {
		int a=7;
		int b=4;
		System.out.println(a+"+"+b+"="+(a+b));
	}

}
