package basic03.oper;

public class OpTest12 {
	public static void main(String[] args) {
		System.out.println("4~15");
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println((int)(Math.random()*12+4));
		System.out.println();
		
		
		
		System.out.println("600~2300");
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
		System.out.println((int)(Math.random()*18+6)*100);
	}

}
