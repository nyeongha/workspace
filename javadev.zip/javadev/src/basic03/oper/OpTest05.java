package basic03.oper;

public class OpTest05 {
	public static void main(String[] args) {
		int a=5;
		++a;
		System.out.println("a="+a);
	}

}
