package basic03.oper;

public class OpTest06 {
	public static void main(String[] args) {
		int a=5;
		
		int b=++a;
		System.out.println("a="+a);
		System.out.println("b="+b);
	}

}
