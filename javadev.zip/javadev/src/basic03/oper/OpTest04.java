package basic03.oper;

public class OpTest04 {
	public static void main(String[] args) {
		System.out.println(5*10>=20); 	//산술연산자가 먼저 수행됨
		System.out.println(50>=100-60);
	}

}
