package basic03.oper;

public class OpTest08 {
	
	public static void main(String[] args) {
		int a=5;
		a+=5;	//a=a+5
		System.out.println(a);
		
		a-=5;	//a=a-5
		System.out.println(a);
		
		a*=5;	//a=a*5
		System.out.println(a);
		
		a/=5;	//a=a/5
		System.out.println(a);
		
		a%=5;	//a=a%5
		System.out.println(a);
		
	}

}
