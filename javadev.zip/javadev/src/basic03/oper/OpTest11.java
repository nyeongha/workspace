package basic03.oper;

public class OpTest11 {
	public static void main(String[] args) {
		double d=10;	//자동타입변환,자동형변환
		System.out.println(d);
		int i = (int)3.141592;
		
		System.out.println(i);
		
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
		System.out.println((int)(Math.random()*6+1));
	}

}
