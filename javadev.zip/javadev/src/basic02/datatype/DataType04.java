package basic02.datatype;

public class DataType04 {
	
	public static void main(String[] args) {
		char value7='\u0041';
		System.out.println(value7);
	}

}
