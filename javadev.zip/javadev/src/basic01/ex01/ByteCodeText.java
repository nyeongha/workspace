package basic01.ex01;

class A{
	
}
class B{
	
}

class C{
	class D{
		
	}
	
}


public class ByteCodeText {
	public static void main(String[] args) {
		
	}

}
